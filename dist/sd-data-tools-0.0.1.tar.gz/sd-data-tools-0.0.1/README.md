A collection of useful scripts for data manipulation, analysis and plotting
